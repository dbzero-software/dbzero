from setuptools import setup

setup(
    name='dbzero_ce',
    version='0.0.1',
    description='DBZero community edition',
    packages=['dbzero_ce']
)
